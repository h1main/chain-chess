const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

let rooms = {};
let totalUsers = 0;

function createState(size, players){
    return {
        size,
        players,
        board: Array.from({length:size}, () =>
            Array.from({length:size}, () => ({owner:null,count:0}))
        ),
        current: 0,
        round: 0,
        alive: Array(players).fill(true),
        played: Array(players).fill(false),
        gameOver: false,
        animating: false
    };
}

function getRoom(id,size,players){
    if(!rooms[id]){
        rooms[id]={state:createState(size,players),clients:new Set()};
    }
    return rooms[id];
}

function tryDeleteRoom(id){
    if(rooms[id] && rooms[id].clients.size===0){
        delete rooms[id];
    }
}

function broadcast(room){
    let data=JSON.stringify({...room.state,totalUsers});
    room.clients.forEach(ws=>{
        if(ws.readyState===1) ws.send(data);
    });
}

/* ===== 异步分裂动画 ===== */
async function explodeLoop(room){

    let s=room.state;
    if(s.animating) return;
    s.animating=true;

    let changed=true;

    while(changed){
        changed=false;

        let list=[];
        for(let i=0;i<s.size;i++){
            for(let j=0;j<s.size;j++){
                if(s.board[i][j].count>=4){
                    list.push([i,j]);
                }
            }
        }

        if(list.length){
            list.forEach(([x,y])=>explode(s,x,y));
            broadcast(room);
            await sleep(120); // ⭐ 动画延迟
            changed=true;
        }
    }

    s.animating=false;
}

function explode(s,x,y){
    let owner=s.board[x][y].owner;
    s.board[x][y]={owner:null,count:0};

    [[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx,dy])=>{
        let nx=x+dx,ny=y+dy;
        if(nx>=0&&nx<s.size&&ny>=0&&ny<s.size){
            let c=s.board[nx][ny];
            c.owner=owner;
            c.count++;
        }
    });
}

function sleep(ms){
    return new Promise(r=>setTimeout(r,ms));
}

function checkOut(s){
    let exist=new Set();
    s.board.forEach(r=>r.forEach(c=>{
        if(c.owner!=null) exist.add(c.owner);
    }));

    for(let i=0;i<s.players;i++){
        if(s.alive[i]&&s.played[i]&&!exist.has(i)){
            s.alive[i]=false;
        }
    }

    if(exist.size===1 && s.round>=s.players){
        s.gameOver=true;
    }
}

function next(s){
    do{
        s.current=(s.current+1)%s.players;
    }while(!s.alive[s.current]);
}

/* ===== WS ===== */
wss.on('connection', ws=>{
    totalUsers++;

    ws.room=null; ws.roomId=null;

    ws.on('message', async msg=>{
        let d=JSON.parse(msg);

        if(d.type==="join"){

            if(ws.room){
                ws.room.clients.delete(ws);
                tryDeleteRoom(ws.roomId);
            }

            ws.roomId=d.room;
            ws.room=getRoom(d.room,d.size,d.players);
            ws.room.clients.add(ws);

            ws.send(JSON.stringify({...ws.room.state,totalUsers}));
        }

        if(d.type==="click" && ws.room){
            let s=ws.room.state;
            if(s.animating || s.gameOver) return;

            let c=s.board[d.x][d.y];

            if(s.round>=s.players && c.owner===null) return;
            if(c.owner!==null && c.owner!==s.current) return;

            if(c.owner===null){
                c.owner=s.current;
                c.count=3;
            }else c.count++;

            s.played[s.current]=true;
            s.round++;

            await explodeLoop(ws.room);

            checkOut(s);
            next(s);

            broadcast(ws.room);
        }

        if(d.type==="reset" && ws.room){
            let s=ws.room.state;
            ws.room.state=createState(s.size,s.players);
            broadcast(ws.room);
        }
    });

    ws.on('close', ()=>{
        totalUsers--;
        if(ws.room){
            ws.room.clients.delete(ws);
            tryDeleteRoom(ws.roomId);
        }
    });
});

console.log("WS running 8080");